create function fmcs_smiles(text) returns text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT CAST( fmcs_smiles(CAST($1 AS CSTRING), CAST('' AS CSTRING)) AS text);
$$;
