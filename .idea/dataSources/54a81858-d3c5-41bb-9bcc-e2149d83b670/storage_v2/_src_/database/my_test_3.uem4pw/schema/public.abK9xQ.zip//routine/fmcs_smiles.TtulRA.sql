CREATE FUNCTION fmcs_smiles(text, text)
  RETURNS text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT CAST( fmcs_smiles(CAST($1 AS CSTRING), CAST($2 AS CSTRING)) AS text);
$$;

